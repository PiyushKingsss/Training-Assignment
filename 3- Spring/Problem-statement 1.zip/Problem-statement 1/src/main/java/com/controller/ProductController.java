package com.controller;

import java.util.List;

import javax.transaction.Transactional;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.entity.Product;
import com.service.ProductService;


@Controller
@RequestMapping("/product")
public class ProductController {
	
	@Autowired
	private ProductService productService;
	
	public ProductController() {
		super();
		System.out.println("\nProductController - Constructor\n");
	}
	
	@GetMapping("/list")
	@Transactional
	public String showProducts(Model model, 
			@RequestParam(name = "sortby", required = false) String sortBy, 
			RedirectAttributes redirectAttributes) {
		List<Product> products = null;
		
		System.out.println("\nSort By Field: " + sortBy + "\n");
		
		if(sortBy != null) {
			 products = productService.getProducts(sortBy);
		}else {
			redirectAttributes.addAttribute("sortby", "lastName");
			return "redirect:/product/list";
		}

		model.addAttribute("products", products);
		
		return "product-list";
	}
	
	@GetMapping("/add")
	public String getAddProductForm(Model model) {
		Product newProduct = new Product();
		model.addAttribute("product", newProduct);
		return "product-form";
	}
	
	@PostMapping("/add")
	public String saveProduct(@ModelAttribute("product") Product newProduct) {
		System.out.println("New Product: " + newProduct);
		productService.saveProduct(newProduct);
		return "redirect:/product/list";
	}
	
	@GetMapping("/update")
	public String getUpdateProductForm(@RequestParam int productId, Model model) {
		Product product = productService.getProductById(productId);
		model.addAttribute("product", product);
		return "product-form";
	}
	
	@GetMapping("/delete")
	public String deleteProduct(@RequestParam("productId") int productId) {
		productService.deleteProductById(productId);
		return "redirect:/product/list";
	}
	
	
}