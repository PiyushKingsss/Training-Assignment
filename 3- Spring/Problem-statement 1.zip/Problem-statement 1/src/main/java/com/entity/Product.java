package com.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "product")
public class Product {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private Integer id;
	
	@Column(name="Name")
	private String Name;
	
	@Column(name="Price")
	private Integer Price;
	
	@Column(name="Quantity")
	private Integer Quantity;
	
	public Product() {
		super();
	}

	public Product(String Name) {
		super();
		this.Name = Name;
		
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFirstName() {
		return Name;
	}

	public void setFirstName(String Name) {
		this.Name = Name;
	}

	public Integer getPrice() {
		return Price;
	}

	public void setPrice(Integer Price) {
		this.Price = Price;
	}

	public Integer getQuantity() {
		return Quantity;
	}

	public void setQuantity(Integer Quantity) {
		this.Quantity = Quantity;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", Name=" + Name + ", Price=" + Price + ", Quantity=" + Quantity + "]";
	}


	
}
