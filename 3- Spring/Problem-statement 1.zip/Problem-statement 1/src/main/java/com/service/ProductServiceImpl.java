package com.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.ProductDAO;
import com.entity.Product;




@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductDAO cdao;
	
	@Transactional
	public List<Product> getProducts(String sortBy) {
		return cdao.getProducts(sortBy);
	}

	@Transactional
	public void saveProduct(Product newProduct) {
		cdao.saveProduct(newProduct);
	}

	@Transactional
	public Product getProductById(int productId) {
		return cdao.getProductById(productId);
	}

	@Transactional
	public void deleteProductById(int productId) {
		cdao.deleteProductById(productId);
	}

	

	

}