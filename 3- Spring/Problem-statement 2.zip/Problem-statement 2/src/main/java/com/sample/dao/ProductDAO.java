package com.sample.dao;


import java.util.List;

import com.sample.model.Product;

public interface ProductDAO {

	public List<Product> getProducts(String sortby);

	public void saveProduct(Product newProduct);
		
	public Product getProductById(int productId);
	
	public void deleteProductById(int productId);
}