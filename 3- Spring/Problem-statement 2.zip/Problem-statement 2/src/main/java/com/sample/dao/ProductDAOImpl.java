package com.sample.dao;

import java.util.List;
import com.sample.model.Product;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;





@Repository
public class ProductDAOImpl implements ProductDAO {

	@Autowired
	SessionFactory sessionFactory;
	
	public List<Product> getProducts(String sortby) {
		Session session = sessionFactory.getCurrentSession();
		String sortField = null;
		
		
		
		String sql = "from Product order by " + sortField;
		
		Query<Product> getProductQuery = session
				.createQuery(sql, Product.class);
		List<Product> products = getProductQuery.getResultList();
		return products;
	}
	
	public void saveProduct(Product newProduct) {
		Session session = sessionFactory.getCurrentSession();
		session.saveOrUpdate(newProduct);
	}

	public Product getProductById(int productId) {
		return sessionFactory.getCurrentSession().get(Product.class, productId);
	}

	public void deleteProductById(int productId) {
		Session session = sessionFactory.getCurrentSession();
		Product delProduct = session.get(Product.class, productId);
		session.delete(delProduct);
	}
}