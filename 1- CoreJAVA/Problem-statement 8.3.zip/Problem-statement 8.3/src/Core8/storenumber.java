package Core8;

public class storenumber {

	public void read(int n) {
		// TODO Auto-generated method stub
		
	}

	public int getnum() {
		// TODO Auto-generated method stub
		return 0;
	}
	

}
