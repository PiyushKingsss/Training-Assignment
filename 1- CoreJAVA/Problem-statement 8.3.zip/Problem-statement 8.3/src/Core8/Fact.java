package Core8;

import java.io.FileInputStream;

class readfile extends Thread{
	storenumber s;
	readfile(storenumber s)
	{
		this.s=s;
		this.start();
	}
	public void run()
	{
		try
		{
			FileInputStream fis=new FileInputStream("num.txt");
			int n;
			while((n=fis.read())!=-1){
				if(n!=10 && n!=13 && n!=32)
				{
					n= n-48;
					s.read(n);
				}
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
class findfact extends Thread{
	storenumber s;
	findfact(storenumber s){
		this.s=s;
		this.start();
	}
	public void run(){
		int fact,n;
		for(int i=0;i<5;i++){
			fact=1;
			n=s.getnum();
			for(int j=1;j<=n;j++)
				fact=fact*j;
			System.out.println("Factorial of "+n+" is: "+fact);
		}
	}
}
public class Fact{
	public static void main(String [] args){
		storenumber s=new storenumber();
		new readfile(s);
		new findfact(s);
	}
}
	

