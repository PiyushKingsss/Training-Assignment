package Core2;

public class Test {  
    public static void main(String[] args) {  
        //Initialize array  
        int [] arr = new int [] {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};  
        int sum = 0;
        float average;
        
        //Loop through the array to calculate sum of elements  
        for (int i = 0; i < arr.length-3; i++) {  
           sum = sum + arr[i];  
        } 
        int temp;
        arr[15] = sum;
        temp = arr[15];
        temp += sum;
        
        System.out.println("Sum of all the elements of an array: " + sum); 
        System.out.println(temp); 
        
        average = (float)temp / arr.length;
        System.out.println("Average:"+average);
        
        int v;
        arr[16] = (int) average;
        v = arr[16];
        
       
        System.out.println(arr[16]);
        
        int minValue = arr[0];
        for (int i = 0; i < arr.length; i++) {
        	if (arr[i] < minValue)
        		  
                minValue = arr[i];
        }
  
        System.out.println("Smallest element present in given array: " + minValue);
        
        int last;
        arr[17] = minValue;
        last = arr[17];
        }
      
         
    }  
  
	   
	

