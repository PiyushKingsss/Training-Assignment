package Core81;

public class Counter implements Runnable {

	public static void main(String[] args) {
		Storage store = new Storage();
		Counter c1 = new Counter(store);
		Printer p1 = new Printer(store);
	}

	Storage st;

	public Counter(Storage store) {
		st = store;
		new Thread(this, "Counter").start();

	}

	@Override
	public void run() {
		for (int i = 0; i < 10; i++) {
			st.setValue(i);
		}

	}

}

class Printer implements Runnable {
	Storage st;

	public Printer(Storage st) {
		this.st = st;
		new Thread(this, "Printer").start();
	}

	@Override
	public void run() {
		for (int i = 0; i < 10; i++)
			System.out.println(Thread.currentThread().getName() + " " + st.getValue());
	}

}

class Storage {
	int i;

	public synchronized void setValue(int i) {
		this.i = i;
	}

	public synchronized int getValue() {
		return this.i;
	}
}