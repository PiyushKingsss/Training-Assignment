package Core5;

public class Main {
	
	public static void main(String args[]){ 
		String str = "JAVA is Simple";
		StringBuilder input1 = new StringBuilder();
		input1.append(str);
		input1.reverse();
		
		System.out.println(str.toUpperCase());
		System.out.println(str.toLowerCase());
		System.out.print(str.charAt(0)+" ");
		System.out.print(str.charAt(5)+ " ");
		System.out.println(str.charAt(8));
		
		
		
		
		System.out.println(input1);
		System.out.println(str.length());
		
		
	}

}
