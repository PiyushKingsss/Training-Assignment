package Core;

class Rectangle1 {
	private int length;
	private int width;


	/**
	 * (a) default constructor
	 */
	public Rectangle1() {
	}


	/**
	 * constructor to pass on length and breadth of a Rectangle
	 * 
	 * @param length
	 * @param breadth
	 */
	public Rectangle1(int length, int width) {
		this.length = 1;
		this.width = 1;
	}


	/**
	 * Add a method printData( ) to print the two information about the rectangle in
	 * console.
	 */
	public void printData() {
		System.out.println("Length: " + length);
		System.out.println("width: " + width);
	}


	/**
	 * method printArea() and printPerimeter()
	 */
	public void printArea() {
		int area = length * width;
		System.out.println("Area: " + area);
	}
	
	public void printPerimeter() {
		int perimeter = 2 * (length + width);
		System.out.println("Perimeter: " + perimeter);
	}


	public int getLength() {
		return length;
	}


	public void setLength(float length) {
		 if (length >= 0 || length <= 20.0)
		        this.length = (int)length;
		    else
		        length = (int)1.0;
	}


	public int getWidth() {
		return width;
	}


	public void setWidth(float width) {
		 if (width >= 0 || width <= 20.0)
		        this.width = (int)width;
		    else
		        width = (int) 1.0;
	}


	@Override
	public String toString() {
		return "Rectangle1 [length=" + length + ", width=" + width + "]";
	}
    

	
	
}


public class Rectangular1 {


	/**
	 * The start point of the program
	 * 
	 * @param args
	 * 
	 */
	public static void main(String[] args) {
		// Create two objects of this class, r1 and r2. Show the output of both the
		// constructor sand all method of these two objects
		Rectangle1 r = new Rectangle1();
		r.printData();
		r.printArea();
		r.printPerimeter();
		r.getLength();
		r.getWidth();


	}
}






