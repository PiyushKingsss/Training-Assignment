package Core5;

import java.util.Arrays;

public class Split {
	public static void main(String args[]){ 
	
	String number = "23+45-(343/12)";
	String[] split = number.split("(?<=\\d)(?=\\D)|(?<=\\D)(?=\\d)");
	System.out.println(Arrays.toString(split));
	}
	
}
