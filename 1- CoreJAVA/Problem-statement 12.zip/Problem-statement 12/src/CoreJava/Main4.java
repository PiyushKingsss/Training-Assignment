package CoreJava;
class Main4 {
    public static int firstRepeated(int[] arr, int n)
    {
        int max = 0;
        for (int x = 0; x < n; x++) {
            if (arr[x] > max) {
                max = arr[x];
            }
        }
        int temp[]
            = new int[max + 1]; // the idea is to use
                                // temporary array as hashmap
       // Arrays.fill(temp, 0);
 
        for (int x = 0; x < n; x++) {
            int num = arr[x];
            temp[num]++;
        }
        for (int x = 0; x < n; x++) {
            int num = arr[x];
            if (temp[num] > 1) {
                return x;
            }
        }
 
        return -1; // if no repeating element found
    }
    public static void main(String[] args)
    {
        int[] arr = { 1, 2, 3, 10, 2, 4, 5, 7, 8 };
 
        int n = arr.length;
        int index = firstRepeated(
            arr,
            arr.length); // index Of 1st repeating number
        if (index != -1) {
            System.out.println("First Repeated Element is:  "
                               + arr[index]);
        }
        else {
            System.out.println("No Repeating Number Found");
        }
    }
}
