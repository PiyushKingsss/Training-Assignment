package Core7;

import java.io.*;
public class SerializeDemo {

   public static void main(String [] args) {
      Employee e = new Employee();
      e.name = "Reyan Parag";
      e.address = "Phokka Kuan, Ambehta Peer";
      e.RollNumber = 11122333;
      e.age = 19;
      
      try {
         FileOutputStream fileOut =
         new FileOutputStream("P:\\MPHASIS\\Core1.txt");
         ObjectOutputStream out = new ObjectOutputStream(fileOut);
         out.writeObject(e);
         out.close();
         fileOut.close();
         System.out.printf("Serialized data is saved in directory");
      } catch (IOException i) {
         i.printStackTrace();
      }
   }
}
