package Core7;

public class Employee implements java.io.Serializable {
	   public String name;
	   public String address;
	   public int age;
	   public int RollNumber;
	   
	   public void mailCheck() {
	      System.out.println("Mailing a check to " + name + " " + address);
	   }
	}