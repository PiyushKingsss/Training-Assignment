package Core;

import java.util.Scanner;

class Book{
	String book_title;
	double book_price;
	
	Book(String title,double price){
		book_title = title;
		book_price = price;
		
	}

	public String getBook_title() {
		return book_title;
	}

	public void setBook_title(String book_title) {
		this.book_title = book_title;
	}

	public double getBook_price() {
		return book_price;
	}

	public void setBook_price(double book_price) {
		this.book_price = book_price;
	}
	
	
}
public class TestBook {
	static Scanner sc = new Scanner(System.in);
	public static void createBooks(Book[] b) {
		for(int i=0;i<b.length;i++) {
			System.out.println("Enter book" + (i+1)+ "details:");
			System.out.println("Title:");
			sc.nextLine();
			String t = sc.nextLine();
			System.out.println("Price:");
			double p = sc.nextDouble();
			b[i] = new Book(t,p);
		}
	}
	public static void showBooks(Book[] b) {
		System.out.println("Book Title\t\tprice");
		System.out.println("---------------------");
		String r ="RS";
		for(int i=0;i<b.length;i++) {
			System.out.println(b[i].getBook_title());
			System.out.println(b[i].getBook_price());
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Number of books:");
		int n = sc.nextInt();
		Book[] b = new Book[n];
		createBooks(b);
		showBooks(b);
		

	}

}
