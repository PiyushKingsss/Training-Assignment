package Core3;

abstract class Instrument

{

public abstract void Play();



}