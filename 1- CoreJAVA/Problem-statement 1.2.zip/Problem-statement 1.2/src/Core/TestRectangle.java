package Core;

public class TestRectangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle r1 = new Rectangle();
		Rectangle r2 = new Rectangle(4, 4);
		Rectangle r3 = new Rectangle(5, 9);
		Rectangle r4 = new Rectangle(6, 8);
		Rectangle r5 = new Rectangle(3, 4);
		r1.printData();
		r1.printArea();
		
		r2.printData();
		r2.printArea();
		
		r3.printData();
		r3.printArea();
		
		r4.printData();
		r4.printArea();
		
		r5.printData();
		r5.printArea();
		
		

	}

}
