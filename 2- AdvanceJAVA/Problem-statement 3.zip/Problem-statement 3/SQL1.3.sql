SELECT * FROM store.order_details;
use store;

insert into books(Book_id,Book_Name,Author,Price)
values(5,'What is HTML5','Brett McClaughlin',300);
insert into books(Book_id,Book_Name,Author,Price)
values(6,'HTML File in Action','Joe Lennon',569);


insert into users(first_name,address,email,user_name,password,registration_date)
values('Hari','Chandan Nagar','Hari.reddif369@gmail.com',9576258476,'Adam99@','2016-11-08');
insert into users(first_name,address,email,user_name,password,registration_date)
values('Mona','Rakshak Nagar','Mona9@gmail.com',7658902768,'pinaki9@','2016-11-08');
insert into users(first_name,address,email,user_name,password,registration_date)
values('Narendra','Rajpath','Naru17mishra369@gmail.com',7256809157,'Delhi9%','2016-11-08');



insert into order_details(Order_Id,Book_Id,Cust_Name,Phone_No,Address,Order_Date,Quantity)
values(2,4,'Suresh',67904849,'Radhika Vihar','2016-11-08',2);
insert into order_details(Order_Id,Book_Id,Cust_Name,Phone_No,Address,Order_Date,Quantity)
values(3,20,'Rajesh',87904849,'Rakshak Vihar','2016-11-08',4);
insert into order_details(Order_Id,Book_Id,Cust_Name,Phone_No,Address,Order_Date,Quantity)
values(4,25,'Rita',94904849,'Nathuwawala','2016-11-08',8);
